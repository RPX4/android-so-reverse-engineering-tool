#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SO Analyzer Legendary - أداة تحليل ملفات .so
Copyright (c) SHBILY & RP_X4@
"""

import r2pipe
import sys
import os
import json
import re
import time
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.prompt import Prompt, IntPrompt
from rich.align import Align
from rich.text import Text
from rich import box

console = Console()

# ============================================================
# نصوص الترجمة (i18n)
# ============================================================
TEXTS = {
    "ar": {
        "welcome": "مرحباً بك في أداة تحليل ملفات .so الأسطورية",
        "choose_lang": "اختر اللغة / Choose language",
        "lang_ar": "1) العربية",
        "lang_en": "2) English",
        "invalid_lang": "اختيار غير صالح، حاول مرة أخرى.",
        "ask_path": "أدخل مسار ملف .so (أو اسمه إذا كان في نفس المجلد)",
        "file_not_found": "الملف غير موجود: {}",
        "starting": "بدء التحليل الشامل للملف: {}",
        "loading_r2": "جارٍ فتح الملف عبر radare2...",
        "analyzing": "جارٍ التحليل الكامل (aaa)...",
        "extracting_r2_strings": "استخراج السلاسل النصية عبر radare2...",
        "extracting_py_strings": "استخراج السلاسل النصية عبر محرك Python...",
        "disassembling_full": "تفكيك الملف بالكامل (pdf @@f)...",
        "reading_sections": "قراءة الأقسام (Sections)...",
        "processing_section": "معالجة القسم: {}",
        "writing_output": "كتابة الملف الناتج...",
        "done": "تم إنشاء ملف التحليل بنجاح: {}",
        "preview_strings": "معاينة أول 10 سلاسل (radare2)",
        "preview_asm": "معاينة أول 10 أسطر من التفكيك الكامل",
        "preview_py_strings": "معاينة أول 10 سلاسل (محرك Python)",
        "preview_sections": "معاينة أول 10 أقسام (Sections)",
        "no_strings": "(لا توجد سلاسل)",
        "no_asm": "(لا توجد تعليمات)",
        "no_sections": "(لا توجد أقسام)",
        "stats_title": "إحصائيات التحليل",
        "stat_r2": "سلاسل radare2",
        "stat_py": "سلاسل Python",
        "stat_sections": "عدد الأقسام",
        "stat_size": "حجم الملف",
        # عناوين داخل الملف الناتج
        "hdr_r2_strings": "المحرك الأول: سلاسل radare2 (izzj)",
        "hdr_full_asm": "التفكيك الكامل للملف (ASM)",
        "hdr_sections": "تحليل الأقسام (Sections) بشكل منفصل",
        "hdr_py_strings": "المحرك الثاني: استخراج Python الخالص",
        "sec_disasm": "تفكيك القسم",
        "sec_strings": "سلاسل القسم (من radare2)",
        "sec_none_strings": "(لا توجد سلاسل في هذا القسم)",
        "sec_none_asm": "(لا توجد تعليمات قابلة للتفكيك)",
        "summary_total_r2": "إجمالي سلاسل radare2",
        "summary_total_py": "إجمالي سلاسل Python",
        "err_sections_json": "[!] فشل في قراءة قائمة الأقسام.",
        "err_disasm": "[!] خطأ في التفكيك: {}",
        "copyright": "حقوق النشر (c) SHBILY & RP_X4@",
    },
    "en": {
        "welcome": "Welcome to the Legendary SO Analyzer",
        "choose_lang": "Choose language",
        "lang_ar": "1) العربية",
        "lang_en": "2) English",
        "invalid_lang": "Invalid choice, try again.",
        "ask_path": "Enter the path to the .so file (or name if in current dir)",
        "file_not_found": "File not found: {}",
        "starting": "Starting full analysis of: {}",
        "loading_r2": "Opening file via radare2...",
        "analyzing": "Running full analysis (aaa)...",
        "extracting_r2_strings": "Extracting strings via radare2...",
        "extracting_py_strings": "Extracting strings via Python engine...",
        "disassembling_full": "Disassembling whole file (pdf @@f)...",
        "reading_sections": "Reading sections...",
        "processing_section": "Processing section: {}",
        "writing_output": "Writing output file...",
        "done": "Analysis file created successfully: {}",
        "preview_strings": "Preview: first 10 strings (radare2)",
        "preview_asm": "Preview: first 10 lines of full ASM",
        "preview_py_strings": "Preview: first 10 strings (Python engine)",
        "preview_sections": "Preview: first 10 sections",
        "no_strings": "(no strings)",
        "no_asm": "(no instructions)",
        "no_sections": "(no sections)",
        "stats_title": "Analysis Statistics",
        "stat_r2": "radare2 strings",
        "stat_py": "Python strings",
        "stat_sections": "Sections count",
        "stat_size": "File size",
        # headers inside output
        "hdr_r2_strings": "Engine 1: radare2 strings (izzj)",
        "hdr_full_asm": "Full file disassembly (ASM)",
        "hdr_sections": "Per-Section analysis",
        "hdr_py_strings": "Engine 2: Pure Python extraction",
        "sec_disasm": "Section disassembly",
        "sec_strings": "Section strings (from radare2)",
        "sec_none_strings": "(no strings in this section)",
        "sec_none_asm": "(no disassemblable instructions)",
        "summary_total_r2": "Total radare2 strings",
        "summary_total_py": "Total Python strings",
        "err_sections_json": "[!] Failed to parse sections list.",
        "err_disasm": "[!] Disassembly error: {}",
        "copyright": "Copyright (c) SHBILY & RP_X4@",
    },
}


# ============================================================
# البانر
# ============================================================
def show_banner(lang):
    banner_text = r"""
   _____ _    _ ____  _____ _      __   __
  / ____| |  | |  _ \|_   _| |     \ \ / /
 | (___ | |__| | |_) | | | | |      \ V / 
  \___ \|  __  |  _ <  | | | |       | |  
  ____) | |  | | |_) | | | | |____  _| |_ 
 |_____/|_|  |_|____/  |_| |______||_____|
                                          
        RP_X4@  ~  Legendary SO Analyzer
"""
    console.print(Panel(
        Align.center(Text(banner_text, style="bold cyan")),
        border_style="magenta",
        subtitle=f"[bold yellow]{TEXTS[lang]['copyright']}[/bold yellow]"
    ))


# ============================================================
# المحرك الثاني: استخراج السلاسل عبر Python
# ============================================================
def extract_strings_python(data, min_len=4):
    results = []
    pattern = re.compile(rb'[\x20-\x7e]{%d,}' % min_len)
    for match in pattern.finditer(data):
        try:
            s = match.group().decode('ascii', errors='ignore')
            if s.strip():
                results.append((match.start(), s))
        except Exception:
            pass
    return results


# ============================================================
# المحرك الأول: استخراج السلاسل عبر radare2
# ============================================================
def get_r2_strings(r2):
    try:
        return json.loads(r2.cmd("izzj"))
    except json.JSONDecodeError:
        return []


# ============================================================
# عرض المعاينة باستخدام rich
# ============================================================
def preview_strings(items, title, no_data_msg):
    """items: list of dict (radare2) أو (offset, str)"""
    table = Table(title=title, box=box.ROUNDED, border_style="green", show_lines=False)
    table.add_column("#", style="dim", width=3)
    table.add_column("Address", style="cyan", width=12)
    table.add_column("Value", style="white")
    count = 0
    for it in items[:10]:
        count += 1
        if isinstance(it, dict):
            addr = it.get("vaddr", it.get("paddr", 0))
            val = it.get("string", "").replace("\n", "\\n").replace("\r", "\\r")
            table.add_row(str(count), f"0x{addr:08x}", val[:80])
        else:
            offset, s = it
            val = s.replace("\n", "\\n").replace("\r", "\\r")
            table.add_row(str(count), f"0x{offset:08x}", val[:80])
    if count == 0:
        console.print(Panel(no_data_msg, border_style="red"))
    else:
        console.print(table)


def preview_asm(asm_text, title, no_data_msg):
    lines = [l for l in asm_text.splitlines() if l.strip()][:10]
    if not lines:
        console.print(Panel(no_data_msg, border_style="red"))
        return
    body = "\n".join(lines)
    console.print(Panel(body, title=title, border_style="green", box=box.ROUNDED))


def preview_sections(sections, title, no_data_msg):
    table = Table(title=title, box=box.ROUNDED, border_style="green")
    table.add_column("#", style="dim", width=3)
    table.add_column("Name", style="cyan")
    table.add_column("vaddr", style="magenta")
    table.add_column("size", style="yellow")
    count = 0
    for sec in sections[:10]:
        count += 1
        table.add_row(
            str(count),
            sec.get("name", "?"),
            f"0x{sec.get('vaddr', 0):08x}",
            f"0x{sec.get('vsize', 0):x}",
        )
    if count == 0:
        console.print(Panel(no_data_msg, border_style="red"))
    else:
        console.print(table)


# ============================================================
# كتابة الملف الناتج
# ============================================================
def write_output_file(output_file, T, r2_strings, full_asm, sections,
                      py_strings, r2, lang):
    with open(output_file, "w", encoding="utf-8") as f:
        # ----------- 1) سلاسل radare2 ------------
        f.write("╔" + "═" * 58 + "╗\n")
        f.write("║" + T["hdr_r2_strings"].center(58) + "║\n")
        f.write("╚" + "═" * 58 + "╝\n\n")
        if r2_strings:
            for s in r2_strings:
                addr = s.get("vaddr", s.get("paddr", 0))
                size = s.get("size", 0)
                val = s.get("string", "").replace("\n", "\\n").replace("\r", "\\r")
                f.write(f"[0x{addr:08x}] (size={size:3d}) {val}\n")
        else:
            f.write(T["no_strings"] + "\n")
        f.write("\n\n")

        # ----------- 2) التفكيك الكامل ------------
        f.write("╔" + "═" * 58 + "╗\n")
        f.write("║" + T["hdr_full_asm"].center(58) + "║\n")
        f.write("╚" + "═" * 58 + "╝\n\n")
        f.write(full_asm if full_asm else T["no_asm"] + "\n")
        f.write("\n\n")

        # ----------- 3) الأقسام ------------
        f.write("╔" + "═" * 58 + "╗\n")
        f.write("║" + T["hdr_sections"].center(58) + "║\n")
        f.write("╚" + "═" * 58 + "╝\n\n")
        for sec in sections:
            sec_name = sec.get("name", "unknown")
            vaddr = sec.get("vaddr", 0)
            vsize = sec.get("vsize", 0)
            if vsize == 0:
                continue
            f.write("┌" + "─" * 58 + "┐\n")
            f.write(f"│ Section: {sec_name:<48} │\n")
            f.write(f"│ vaddr=0x{vaddr:08x}  size=0x{vsize:08x} ({vsize} bytes)      │\n")
            f.write("└" + "─" * 58 + "┘\n\n")

            f.write(f"[*] {T['sec_disasm']} {sec_name}:\n")
            try:
                r2.cmd(f"s {vaddr}")
                asm_sec = r2.cmd(f"pd {vsize}")
                f.write(asm_sec if asm_sec else T["sec_none_asm"] + "\n")
            except Exception as e:
                f.write(T["err_disasm"].format(e) + "\n")

            f.write(f"\n[*] {T['sec_strings']}:\n")
            found = False
            for s in r2_strings:
                s_addr = s.get("vaddr", s.get("paddr", 0))
                if vaddr <= s_addr < (vaddr + vsize):
                    val = s.get("string", "").replace("\n", "\\n")
                    f.write(f"  [0x{s_addr:08x}] {val}\n")
                    found = True
            if not found:
                f.write("  " + T["sec_none_strings"] + "\n")
            f.write("\n")

        # ----------- 4) سلاسل Python ------------
        f.write("\n")
        f.write("╔" + "═" * 58 + "╗\n")
        f.write("║" + T["hdr_py_strings"].center(58) + "║\n")
        f.write("╚" + "═" * 58 + "╝\n\n")
        if py_strings:
            for off, s in py_strings:
                val = s.replace("\n", "\\n").replace("\r", "\\r")
                f.write(f"[0x{off:08x}] {val}\n")
        else:
            f.write(T["no_strings"] + "\n")

        f.write("\n" + "=" * 60 + "\n")
        f.write(f"{T['summary_total_r2']}: {len(r2_strings)}\n")
        f.write(f"{T['summary_total_py']}:  {len(py_strings)}\n")
        f.write("=" * 60 + "\n")
        f.write(f"{T['copyright']}\n")


# ============================================================
# الدالة الرئيسية
# ============================================================
def main():
    # اختيار اللغة
    console.clear()
    console.print(Panel(
        "[bold cyan]Choose language / اختر اللغة[/bold cyan]\n\n"
        "  [bold yellow]1)[/bold yellow] العربية\n"
        "  [bold yellow]2)[/bold yellow] English",
        border_style="magenta",
        title="[bold]🌐 Language[/bold]"
    ))
    while True:
        choice = Prompt.ask("[bold yellow]>>[/bold yellow]", choices=["1", "2"], default="1")
        if choice in ("1", "2"):
            lang = "ar" if choice == "1" else "en"
            break

    T = TEXTS[lang]

    # البانر
    console.clear()
    show_banner(lang)
    console.print(Panel(
        Align.center(f"[bold green]{T['welcome']}[/bold green]"),
        border_style="green"
    ))

    # طلب المسار
    so_path = Prompt.ask(f"[bold yellow]{T['ask_path']}[/bold yellow]").strip().strip('"').strip("'")
    if not os.path.exists(so_path):
        console.print(Panel(T["file_not_found"].format(so_path), border_style="red"))
        sys.exit(1)

    output_file = f"{os.path.basename(so_path)}_analysis.txt"
    file_size = os.path.getsize(so_path)

    console.print(Panel(
        f"[bold cyan]{T['starting'].format(so_path)}[/bold cyan]",
        border_style="cyan", box=box.ROUNDED
    ))

    # فتح radare2
    r2 = r2pipe.open(so_path, flags=["-2"])

    try:
        with Progress(
            SpinnerColumn(style="cyan"),
            TextColumn("[bold white]{task.description}"),
            BarColumn(bar_width=30, style="magenta"),
            console=console,
            transient=False,
        ) as progress:

            # 1) تحليل كامل
            task = progress.add_task(T["analyzing"], total=6)
            r2.cmd("aaa")
            progress.advance(task)

            # 2) سلاسل radare2
            progress.update(task, description=T["extracting_r2_strings"])
            r2_strings = get_r2_strings(r2)
            progress.advance(task)
            console.print()
            preview_strings(r2_strings, f"📜 {T['preview_strings']}", T["no_strings"])

            # 3) سلاسل Python
            progress.update(task, description=T["extracting_py_strings"])
            with open(so_path, "rb") as fp:
                raw = fp.read()
            py_strings = extract_strings_python(raw, min_len=4)
            progress.advance(task)
            console.print()
            preview_strings(py_strings, f"🐍 {T['preview_py_strings']}", T["no_strings"])

            # 4) تفكيك كامل
            progress.update(task, description=T["disassembling_full"])
            full_asm = r2.cmd('pdf @@f')
            progress.advance(task)
            console.print()
            preview_asm(full_asm, f"⚙️  {T['preview_asm']}", T["no_asm"])

            # 5) الأقسام
            progress.update(task, description=T["reading_sections"])
            try:
                sections = json.loads(r2.cmd("iSj"))
            except json.JSONDecodeError:
                sections = []
                console.print(Panel(T["err_sections_json"], border_style="red"))
            progress.advance(task)
            console.print()
            preview_sections(sections, f"🧩 {T['preview_sections']}", T["no_sections"])

            # 6) كتابة الملف
            progress.update(task, description=T["writing_output"])
            write_output_file(output_file, T, r2_strings, full_asm, sections,
                              py_strings, r2, lang)
            progress.advance(task)

    finally:
        r2.quit()

    # ملخص نهائي
    console.print()
    stats = Table(title=f"📊 {T['stats_title']}", box=box.ROUNDED, border_style="cyan")
    stats.add_column("Item", style="bold yellow")
    stats.add_column("Value", style="bold white")
    stats.add_row(T["stat_r2"], str(len(r2_strings)))
    stats.add_row(T["stat_py"], str(len(py_strings)))
    stats.add_row(T["stat_sections"], str(len(sections)))
    stats.add_row(T["stat_size"], f"{file_size:,} bytes")
    console.print(stats)

    console.print()
    console.print(Panel(
        Align.center(f"[bold green]✅ {T['done'].format(output_file)}[/bold green]"),
        border_style="green", box=box.DOUBLE
    ))
    console.print(Align.center(f"[dim]{T['copyright']}[/dim]"))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        console.print("\n[bold red]Interrupted.[/bold red]")
        sys.exit(130)